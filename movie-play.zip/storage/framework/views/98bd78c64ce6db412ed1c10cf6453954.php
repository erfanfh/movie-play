<?php $__env->startSection('title', 'Register'); ?>
<?php $__env->startSection('action'); ?>
    <?php echo e(route('register.post')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('csrf'); ?>
    <?php echo csrf_field(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <?php echo e(route('login')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('message', 'Have'); ?>
<?php $__env->startSection('button', 'Register'); ?>

<?php echo $__env->make('auth.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xamp\htdocs\movie-play\resources\views/auth/register.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex px-5 text-center flex-column justify-content-center align-items-center" style="height: 100vh">
        <div class="h2">Score: <?php echo e($score); ?></div>
        <div class="h1"><?php echo e($message); ?></div>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Back to home</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xamp\htdocs\movie-play\resources\views/game/result.blade.php ENDPATH**/ ?>
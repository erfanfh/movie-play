<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex flex-column align-items-center justify-content-center p-5 mt-5">
            <h2 class=""><?php echo $__env->yieldContent('button'); ?></h2>
            <form class="w-75" action="<?php echo $__env->yieldContent('action'); ?>" method="post">
                <?php echo $__env->yieldContent('csrf'); ?>
                <div class="mb-3">
                    <label class="form-label text-black">Username</label>
                    <input name="username" type="text" class="form-control">
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label class="form-label text-black">Password</label>
                    <input name="password" type="password" class="form-control">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php if(session('message')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>
                <p><a href="<?php echo $__env->yieldContent('link'); ?>" class="link-body-emphasis link-offset-2 link-underline-opacity-25 link-underline-opacity-75-hover"><?php echo $__env->yieldContent('message'); ?> an account?</a></p>
                <button type="submit" class="btn btn-secondary w-100"><?php echo $__env->yieldContent('button'); ?></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xamp\htdocs\movie-play\resources\views/auth/auth.blade.php ENDPATH**/ ?>
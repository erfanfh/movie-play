<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center align-items-center header" style="height: 100vh">
        <div class="card mt-5" style="width: 18rem;">
            <div class="card-body text-center">
                <h5 class="card-title">Guess the movie</h5>
                <p class="card-text">In this game you should guess the movie name or TV show name or anime name by it's
                    poster</p>
                <?php if($memories->all()): ?>
                    <div>
                        <a href="<?php echo e(route('question.show')); ?>" class="card-link btn btn-warning">Continue</a>
                        <a href="<?php echo e(route('question.playover')); ?>" class="card-link btn btn-primary">Play over</a>
                    </div>
                    <div class="mt-1 text-secondary">You can finish your game until <?php echo e($memories->first()->updated_at->addWeek()); ?></div>
                <?php else: ?>
                    <a href="<?php echo e(route('question.show')); ?>" class="card-link btn btn-primary">Play a game</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xamp\htdocs\movie-play\resources\views/game/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('action'); ?>
    <?php echo e(route('login.post')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('csrf'); ?>
    <?php echo csrf_field(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <?php echo e(route('register')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('message', 'Don\'t have'); ?>
<?php $__env->startSection('button', 'Login'); ?>

<?php echo $__env->make('auth.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xamp\htdocs\movie-play\resources\views/auth/login.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column justify-content-center align-items-center px-5 gap-5">
        <div class="h2 align-self-start">Score: <?php echo e(auth()->user()->memories->where('is_active', 1)->first()->score); ?></div>
        <img src="<?php echo e(asset('images') . '/' . $question->image); ?>" alt="movie poster" class="movie-poster">
        <form action="<?php echo e(route('question.checkAnswer', $question)); ?>" method="post" class="d-flex flex-column gap-1">
            <?php echo csrf_field(); ?>
            <div>
                <input type="text" name="answer" class="form-control">
                <div class="form-text">What's this poster for?</div>
            </div>
            <button type="submit" class="btn btn-success">Next</button>
        </form>
    </div>
    <div class="question-cover"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xamp\htdocs\movie-play\resources\views/game/question.blade.php ENDPATH**/ ?>
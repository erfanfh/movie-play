<!doctype html>
<html lang="en">
<head>
    <x-header></x-header>
</head>
<body>
    <x-nav></x-nav>
    @yield('content')
    <x-footer></x-footer>
</body>
</html>
